# coding=utf-8
import os
import media
import fresh_tomatoes

def content_to_list(content):
    """Transfer the content to a list data structure
        Args:
            content => string, the content read from a txt about a movie
            Return:
                  a string list. The first parameter is title, second
                  parameter is the storyline, third parameter is the image
                  url of the poster, the last is the youku url of the
                  movie's trailer"""
    string_list = []
    index = content.find('http')
    preindex = 0
    string_list.append(content[preindex:(index - 1)])
    while index != -1:
        preindex = index
        index = content.find('http', preindex + 4)
        string_list.append(content[preindex:(index - 1)])
    return string_list
    

file_list = os.listdir(r"movies")
movie_list = []
os.chdir(r"movies")
for file_name in file_list:
    f = open(file_name)
    content = f.read()
    string_list = content_to_list(content)
    f.close()
    
    movie = media.Movie(file_name[0:-4],   
                        string_list[0],
                        string_list[1],
                        string_list[2])
    movie_list.append(movie)
os.chdir(r"..")

for movie_file in movie_list:
    print "title"
    print movie_file.title
    print "storyline"
    print movie_file.storyline

fresh_tomatoes.open_movies_page(movie_list)

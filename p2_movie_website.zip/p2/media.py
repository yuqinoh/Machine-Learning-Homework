class Movie():
    """Description of a movie's attibutions, like title, storyline and so on"""
    def __init__(self, title, storyline, poster_image_url, trailer_youku_url):
        """Method description
              Args:
                  title => string, title of a movie
                  storyline => string, a short brief story of this movie.
                  poster_image_url => string, the url that saving a poster image of the movie.
                  trailer_url => string, the url that saving a short trailer of this movie.
                  Return:
                        No return. Initiate an object of the movie class."""
        self.title = title
        self.storyline = storyline
        self.poster_image_url = poster_image_url
        self.trailer_url = trailer_youku_url
